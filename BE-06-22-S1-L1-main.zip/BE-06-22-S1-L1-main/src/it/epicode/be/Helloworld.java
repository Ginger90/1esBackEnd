package it.epicode.be;

public class Helloworld {

	public static void main (String[] args) {
		System.out.println("This is my first Epicode Java Project!");
	}
}



